
import cv2
import numpy as np

def equalize_histogram(image_path: str) -> np.ndarray:
    """
    Realiza equalização de histograma apenas no canal Y de uma imagem RGB convertida para YCrCb.

    Parâmetros:
        image_path (str): Caminho para a imagem RGB.

    Retorno:
        np.ndarray: Imagem RGB com o canal Y equalizado.
    """
    # TODO: Implemente sua solução aqui
    pass


student_result = equalize_histogram('unequal_lighting_color_image.png')
expected_result = cv2.imread('expected_result.png')

if (expected_result == student_result).all():
    print('Success!')