
import cv2
import numpy as np

def verify_laplacian_isotropy(image_path, angle=45):
    """
    Aplica rotação + Laplaciano e Laplaciano + rotação na imagem de entrada
    e retorna o coeficiente de correlação de Pearson entre os dois resultados.

    Parâmetros:
        image_path (str): Caminho para a imagem em tons de cinza.
        angle (float): Ângulo de rotação em graus.

    Retorno:
        float: Coeficiente de correlação de Pearson entre as duas imagens.
    """
    image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    if image is None:
        raise ValueError("Image not found or unable to load.")

    # TODO: Implementar solução aqui    
    result_1 = None
    result_2 = None

    # Flatten and compute correlation
    corr = np.corrcoef(result_1.flatten(), result_2.flatten())[0, 1]
    print(f'Correlation coefficient: {corr}')
    return corr

verify_laplacian_isotropy('example_image.png', angle=45)
# Expected: Correlation coefficient: 0.9621492663463063

verify_laplacian_isotropy('checkerboard_image.png', angle=45)
# Expected: Correlation coefficient: 0.9383739474511829