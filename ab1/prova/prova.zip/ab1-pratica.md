# 🧠 Prova de Processamento Digital de Imagens  
**Disciplina:** Processamento de Imagens  
**Professor:** Tiago Vieira  
**Tema:** Implementação da Imagem Integral em NumPy  
**Data:** `24/04/2025`